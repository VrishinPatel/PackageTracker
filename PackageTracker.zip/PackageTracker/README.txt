Admin Access:

Login: admin
password: admin_password

User Access:

Login: user
password: user_password